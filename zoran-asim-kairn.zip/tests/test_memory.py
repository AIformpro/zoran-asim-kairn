from zoran_kairn.memory.fractal_memory import FractalMemory

def test_add_promote():
    m = FractalMemory()
    for i in range(10):
        m.add("user", f"text {i}")
    assert len(m.long_term) >= 1
