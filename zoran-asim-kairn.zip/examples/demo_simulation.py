import json, random
from zoran_kairn.runtime import ZRuntime

if __name__ == "__main__":
    rt = ZRuntime()
    stimuli = [
        "bravo c'est super",
        "j'ai peur du futur",
        "colère contre l'injustice",
        "love la science ouverte",
        "stress avant la deadline",
    ]
    logs = []
    for i in range(20):
        s = random.choice(stimuli)
        r = rt.handle(s)
        logs.append(r.metrics)
    with open("metrics.json","w",encoding="utf-8") as f:
        json.dump(logs, f, ensure_ascii=False, indent=2)
    print("Wrote metrics.json")
