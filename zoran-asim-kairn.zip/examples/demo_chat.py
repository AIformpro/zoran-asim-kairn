from zoran_kairn.runtime import ZRuntime
from zoran_kairn.modules.kairn.room_framework import RoomContext

if __name__ == "__main__":
    rt = ZRuntime()
    print("Zoran+KAIRN demo. Type 'quit' to exit.")
    while True:
        x = input("you> ").strip()
        if x.lower() in {"quit","exit"}:
            break
        rep = rt.handle(x, room=RoomContext(role="user", situation="chat"))
        print("zoran>", rep.text)
        print("metrics:", rep.metrics)
