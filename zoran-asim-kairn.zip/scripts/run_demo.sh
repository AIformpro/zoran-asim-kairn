#!/usr/bin/env bash
python -m examples.demo_chat
