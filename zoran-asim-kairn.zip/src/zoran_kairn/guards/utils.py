def ema(prev: float, value: float, alpha: float=0.2) -> float:
    return (1-alpha)*prev + alpha*value

def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))

def normalize(x: float, lo: float, hi: float) -> float:
    if hi == lo: 
        return 0.0
    return (x - lo) / (hi - lo)
