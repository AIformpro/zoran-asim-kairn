from __future__ import annotations
from dataclasses import dataclass
from .utils import normalize
from ..memory.fractal_memory import shannon_entropy

@dataclass
class DeltaM113:
    entropy_threshold: float = 3.8  # heuristic for French/English text
    last_entropy: float = 0.0

    def check(self, text: str) -> bool:
        """Return True if stable, False if rollback required."""
        self.last_entropy = shannon_entropy(text)
        return self.last_entropy <= self.entropy_threshold
