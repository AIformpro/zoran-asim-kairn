from dataclasses import dataclass
from ...guards.utils import ema, clamp

@dataclass
class Homoeostasis:
    v: float = 0.0
    a: float = 0.1
    d: float = 0.5
    alpha: float = 0.25

    def update(self, valence: float, arousal: float, dominance: float):
        self.v = ema(self.v, valence, self.alpha)
        self.a = ema(self.a, arousal, self.alpha)
        self.d = ema(self.d, dominance, self.alpha)
        # keep in ranges
        self.v = clamp(self.v, -1.0, 1.0)
        self.a = clamp(self.a, 0.0, 1.0)
        self.d = clamp(self.d, 0.0, 1.0)
        return self.v, self.a, self.d
