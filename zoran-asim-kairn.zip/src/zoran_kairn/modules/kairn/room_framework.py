from dataclasses import dataclass
from typing import Dict

@dataclass
class RoomContext:
    role: str = "observer"
    situation: str = "neutral"
    goal: str = "inform"
    def to_dict(self) -> Dict[str,str]:
        return {"role": self.role, "situation": self.situation, "goal": self.goal}
