from __future__ import annotations
from dataclasses import dataclass
from ..kairn.homoeostasis import Homoeostasis

@dataclass
class EmotionVector:
    valence: float  # [-1,1]
    arousal: float  # [0,1]
    dominance: float  # [0,1]

    def as_tuple(self):
        return (self.valence, self.arousal, self.dominance)

class EmotionMatrix:
    """
    Very lightweight affective estimator (lexical cues + length heuristics).
    No ML deps; purely demonstrative.
    """
    def __init__(self):
        self.homeo = Homoeostasis()

    def infer(self, text: str) -> EmotionVector:
        tl = len(text)
        pos = sum(1 for k in ["bravo","super","merci","heureux","love","great","cool"] if k in text.lower())
        neg = sum(1 for k in ["peur","triste","colère","hate","stress","danger"] if k in text.lower())
        valence = (pos - neg) / 5.0
        valence = max(-1.0, min(1.0, valence))
        arousal = min(1.0, tl/240.0)
        dominance = max(0.0, 1.0 - neg*0.15)
        # homeostatic smoothing
        v,a,d = self.homeo.update(valence, arousal, dominance)
        return EmotionVector(v,a,d)
