from dataclasses import dataclass

@dataclass
class MockReasoner:
    name: str = "mock"
    def respond(self, text: str, vad):
        v,a,d = vad
        # simplistic modulation by affect: add a tag
        tone = "calme" if a < 0.4 else "énergique"
        polarity = "positif" if v >= 0 else "neutre"
        return f"[{self.name}:{tone}:{polarity}] {text}"
