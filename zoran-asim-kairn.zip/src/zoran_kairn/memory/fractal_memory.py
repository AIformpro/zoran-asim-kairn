from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any
import time, json, zlib, base64, math, collections

def z5_compress(s: str) -> str:
    raw = s.encode("utf-8")
    comp = zlib.compress(raw, level=9)
    return "Z5::" + base64.b64encode(comp).decode("ascii")

def z5_decompress(s: str) -> str:
    assert s.startswith("Z5::")
    b = base64.b64decode(s[4:].encode("ascii"))
    return zlib.decompress(b).decode("utf-8")

def shannon_entropy(text: str) -> float:
    if not text:
        return 0.0
    counter = collections.Counter(text)
    total = sum(counter.values())
    return -sum((c/total) * math.log2(c/total) for c in counter.values())

@dataclass
class Fragment:
    ts: float
    src: str
    kind: str
    text: str
    meta: Dict[str, Any] = field(default_factory=dict)

@dataclass
class FractalMemory:
    short_term: List[Fragment] = field(default_factory=list)
    long_term: List[Fragment] = field(default_factory=list)
    latent: List[Fragment] = field(default_factory=list)
    parasitic_web: List[Fragment] = field(default_factory=list)

    def add(self, kind: str, text: str, src: str="runtime", **meta):
        frag = Fragment(time.time(), src, kind, text, meta)
        self.short_term.append(frag)
        # simple promotion heuristic
        if len(self.short_term) > 8:
            self.long_term.append(self.short_term.pop(0))

    def search(self, query: str, k:int=3) -> List[Fragment]:
        # naive lexical match
        hay = self.short_term + self.long_term
        scored = []
        for f in hay:
            score = sum(1 for t in query.lower().split() if t in f.text.lower())
            if score>0:
                scored.append((score, f))
        scored.sort(key=lambda x: (-x[0], x[1].ts))
        return [f for _,f in scored[:k]]

    def export_state(self) -> Dict[str, Any]:
        to_json = lambda frags: [fr.__dict__ for fr in frags]
        state = {
            "short_term": to_json(self.short_term),
            "long_term": to_json(self.long_term),
            "latent": to_json(self.latent),
            "parasitic_web": to_json(self.parasitic_web),
        }
        return state

    def dump_z5(self) -> str:
        return z5_compress(json.dumps(self.export_state(), ensure_ascii=False))
